# Focus ECU Tuner (Etapa 2)

Ford Focus 2012 2.0 Duratec Flex — gerenciador de arquivos e identificação de ECU.
**Não há comunicação com a ECU nem gravação.** A trava de gravação está sempre bloqueada.

## Estrutura
- `core/` Kotlin puro (JVM): identificação da ECU, hash/análise, comparação binária, workspace
  (original protegido, cópias, histórico, auditoria), trava de gravação, interfaces de comunicação, relatório. + testes.
- `app/` Android (Jetpack Compose, Material 3): Painel, ECU, Arquivos, Comparar, Relatório.

## Compilar o APK (Android Studio)
1. Instale o Android Studio (versão recente, com Android SDK 34).
2. File > Open > pasta `FocusEcuTuner`. Aceite baixar o Gradle 8.7 e aguarde o Sync.
3. Build > Build Bundle(s)/APK(s) > Build APK(s). O APK fica em `app/build/outputs/apk/debug/app-debug.apk`.
4. Copie para o celular e instale (permita "fontes desconhecidas"). Ou ligue o celular por USB e clique em Run.

Pela linha de comando (com Gradle instalado): `gradle wrapper --gradle-version 8.7` e depois `./gradlew assembleDebug`.

## Rodar os testes
`./gradlew :core:test` (ou clique direito em `core/src/test` > Run Tests no Android Studio).

## Testar sem ECU
1. Painel: ligue "Modo demonstração" e toque em "Ler identificação (simulada)" (valores fictícios, nada é salvo).
2. ECU: cadastre dados de teste nas duas fontes e veja a situação mudar (confirmada / divergente / parcial).
3. Arquivos: importe qualquer arquivo, crie uma cópia, toque em "Verificar".
4. Comparar: escolha duas versões. Relatório: exporte o .txt.
