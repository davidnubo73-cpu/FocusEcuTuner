package br.focus.ecu.core

import java.nio.file.Files
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import kotlin.test.assertFalse
import kotlin.test.assertNotEquals
import kotlin.test.assertTrue

class EcuIdentifierTest {
    private val ok = EcuData("AU75-12A650-CB", "HW1", "SW1", "EST", "CAL1", DataSource.ETIQUETA)

    @Test fun semFontesNaoConfirma() {
        assertEquals(CompatStatus.NAO_CONFIRMADA, EcuIdentifier.evaluate(null, null).status)
        assertEquals(CompatStatus.NAO_CONFIRMADA, EcuIdentifier.evaluate(ok, null).status)
    }

    @Test fun duasFontesCoerentesConfirmam() {
        val d = ok.copy(partNumber = "au75 12a650 cb", source = DataSource.FERRAMENTA_DIAGNOSTICO)
        assertEquals(CompatStatus.CONFIRMADA, EcuIdentifier.evaluate(ok, d).status)
    }

    @Test fun divergenciaEhDetectada() {
        val d = ok.copy(software = "SW2", source = DataSource.FERRAMENTA_DIAGNOSTICO)
        assertEquals(CompatStatus.DIVERGENTE, EcuIdentifier.evaluate(ok, d).status)
    }

    @Test fun dadosIncompletosSaoParciais() {
        val d = ok.copy(calibration = "", source = DataSource.FERRAMENTA_DIAGNOSTICO)
        assertEquals(CompatStatus.PARCIAL, EcuIdentifier.evaluate(ok, d).status)
    }
}

class FileToolsTest {
    @Test fun sha256Conhecido() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", FileTools.sha256("abc".toByteArray()))
    }

    @Test fun crc32Conhecido() {
        assertEquals("cbf43926", FileTools.crc32("123456789".toByteArray()))
    }

    @Test fun avisaArquivoApagado() {
        val info = FileTools.analyze("x.bin", ByteArray(1024) { 0xFF.toByte() })
        assertTrue(info.notes.any { it.contains("0xFF") })
    }

    @Test fun arquivoVazio() {
        assertEquals(0, FileTools.analyze("v.bin", ByteArray(0)).size)
    }
}

class BinaryDiffTest {
    @Test fun identicos() {
        assertTrue(BinaryDiff.compare(byteArrayOf(1, 2, 3), byteArrayOf(1, 2, 3)).identical)
    }

    @Test fun faixaUnica() {
        val r = BinaryDiff.compare(byteArrayOf(1, 2, 3, 4), byteArrayOf(1, 9, 9, 4))
        assertEquals(listOf(DiffRange(1, 2)), r.ranges)
        assertEquals(2, r.differingBytes)
    }

    @Test fun tamanhosDiferentes() {
        val r = BinaryDiff.compare(byteArrayOf(1, 2, 3), byteArrayOf(1, 2, 3, 4, 5))
        assertFalse(r.sameSize)
        assertEquals(listOf(DiffRange(3, 2)), r.ranges)
    }

    @Test fun diferencaMaisSobra() {
        val r = BinaryDiff.compare(byteArrayOf(1, 2, 3), byteArrayOf(1, 2, 9, 4))
        assertEquals(listOf(DiffRange(2, 2)), r.ranges)
    }
}

class WorkspaceTest {
    private fun novo() = Workspace(Files.createTempDirectory("ws").toFile())

    @Test fun importaEVerifica() {
        val ws = novo()
        val v = ws.importOriginal("orig.bin", byteArrayOf(1, 2, 3))
        assertEquals(Workspace.Kind.ORIGINAL, v.kind)
        assertTrue(ws.verify(v.id))
    }

    @Test fun detectaAdulteracao() {
        val ws = novo()
        val v = ws.importOriginal("orig.bin", byteArrayOf(1, 2, 3))
        val f = ws.fileOf(v.id)
        f.delete()
        f.writeBytes(byteArrayOf(9, 9, 9))
        assertFalse(ws.verify(v.id))
        assertFailsWith<IllegalStateException> { ws.createWorkingCopy(v.id) }
    }

    @Test fun edicaoNaoAlteraOriginal() {
        val ws = novo()
        val o = ws.importOriginal("orig.bin", byteArrayOf(1, 2, 3, 4))
        val e = ws.editBytes(o.id, 1, byteArrayOf(7), "teste")
        assertEquals(listOf<Byte>(1, 7, 3, 4), ws.readBytes(e.id).toList())
        assertEquals(listOf<Byte>(1, 2, 3, 4), ws.readBytes(o.id).toList())
        assertNotEquals(o.sha256, e.sha256)
        assertEquals(o.id, e.parentId)
    }

    @Test fun edicaoForaDoIntervaloFalha() {
        val ws = novo()
        val o = ws.importOriginal("orig.bin", byteArrayOf(1, 2))
        assertFailsWith<IllegalArgumentException> { ws.editBytes(o.id, 2, byteArrayOf(1), "x") }
    }

    @Test fun historicoESobrevivemReabertura() {
        val dir = Files.createTempDirectory("ws").toFile()
        val a = Workspace(dir)
        val o = a.importOriginal("o.bin", byteArrayOf(5))
        a.createWorkingCopy(o.id)
        assertEquals(2, Workspace(dir).list().size)
    }
}

class WriteGateTest {
    private val tudoOk = WriteContext(
        CompatStatus.CONFIRMADA, backupVerified = true, fileIntegrityOk = true, connected = true,
        protocolValidated = true, transportSupportsWrite = true, supplyVoltageOk = true, demoMode = false,
    )

    @Test fun bloqueadoSemProtocolo() {
        assertFalse(WriteGate.evaluate(tudoOk.copy(protocolValidated = false)).allowed)
        assertFalse(WriteGate.evaluate(tudoOk.copy(transportSupportsWrite = false)).allowed)
    }

    @Test fun bloqueadoEmDemo() {
        assertFalse(WriteGate.evaluate(tudoOk.copy(demoMode = true)).allowed)
    }

    @Test fun bloqueadoSemBackupOuIdentidade() {
        assertFalse(WriteGate.evaluate(tudoOk.copy(backupVerified = false)).allowed)
        assertFalse(WriteGate.evaluate(tudoOk.copy(compat = CompatStatus.PARCIAL)).allowed)
        assertFalse(WriteGate.evaluate(tudoOk.copy(supplyVoltageOk = null)).allowed)
    }

    @Test fun liberaSomenteComTudo() {
        assertTrue(WriteGate.evaluate(tudoOk).allowed)
    }

    @Test fun transporteAtualNuncaGrava() {
        assertTrue(UnavailableTransport().writeCalibration(byteArrayOf(1)).isFailure)
        assertTrue(DemoTransport().writeCalibration(byteArrayOf(1)).isFailure)
    }
}
