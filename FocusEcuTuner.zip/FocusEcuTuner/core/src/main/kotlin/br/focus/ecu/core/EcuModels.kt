package br.focus.ecu.core

import java.io.File
import java.util.Properties

enum class DataSource { ETIQUETA, FERRAMENTA_DIAGNOSTICO }

data class EcuData(
    val partNumber: String = "",
    val hardware: String = "",
    val software: String = "",
    val strategy: String = "",
    val calibration: String = "",
    val source: DataSource = DataSource.ETIQUETA,
)

enum class CompatStatus(val rotulo: String) {
    NAO_CONFIRMADA("Não confirmada"),
    PARCIAL("Parcial (dados incompletos)"),
    DIVERGENTE("Divergente entre as fontes"),
    CONFIRMADA("Identidade confirmada por duas fontes"),
}

data class CompatResult(val status: CompatStatus, val motivos: List<String>)

object EcuIdentifier {
    const val REFERENCIA_INICIAL = "AU75/12A650/CB"

    fun normalize(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

    /**
     * Compara os dados da etiqueta física com os lidos por ferramenta de diagnóstico.
     * CONFIRMADA = identidade coerente em duas fontes independentes. Não significa
     * que exista protocolo/hardware validado para gravação.
     */
    fun evaluate(label: EcuData?, diag: EcuData?): CompatResult {
        val motivos = mutableListOf<String>()
        if (label == null) motivos += "Falta cadastrar os dados da etiqueta física."
        if (diag == null) motivos += "Faltam os dados lidos por ferramenta de diagnóstico."
        if (label == null || diag == null) {
            motivos += "Uma única fonte não comprova a identidade da ECU."
            return CompatResult(CompatStatus.NAO_CONFIRMADA, motivos)
        }
        val campos = listOf(
            Triple("Número da peça", { e: EcuData -> e.partNumber }, true),
            Triple("Hardware", { e: EcuData -> e.hardware }, true),
            Triple("Versão de software", { e: EcuData -> e.software }, true),
            Triple("Calibração", { e: EcuData -> e.calibration }, true),
            Triple("Estratégia", { e: EcuData -> e.strategy }, false),
        )
        var diverge = false
        var incompleto = false
        for ((nome, get, obrigatorio) in campos) {
            val a = normalize(get(label))
            val b = normalize(get(diag))
            if (a.isNotEmpty() && b.isNotEmpty() && a != b) {
                diverge = true
                motivos += "$nome diverge entre etiqueta e diagnóstico."
            } else if (obrigatorio && (a.isEmpty() || b.isEmpty())) {
                incompleto = true
                motivos += "$nome não informado nas duas fontes."
            }
        }
        val status = when {
            diverge -> CompatStatus.DIVERGENTE
            incompleto -> CompatStatus.PARCIAL
            else -> CompatStatus.CONFIRMADA
        }
        if (status == CompatStatus.CONFIRMADA) {
            motivos += "Identidade coerente entre as duas fontes. Isso não comprova que existe protocolo/hardware validado para gravação."
        }
        val peca = normalize(label.partNumber)
        if (peca.isNotEmpty() && peca != normalize(REFERENCIA_INICIAL)) {
            motivos += "Número da peça difere da referência inicial $REFERENCIA_INICIAL (apenas informativo)."
        }
        return CompatResult(status, motivos)
    }
}

/** Guarda os dois cadastros (etiqueta e diagnóstico) em um arquivo .properties. */
class EcuStore(private val file: File) {
    fun save(label: EcuData?, diag: EcuData?) {
        val p = Properties()
        put(p, "label", label)
        put(p, "diag", diag)
        file.parentFile?.mkdirs()
        file.outputStream().use { p.store(it, null) }
    }

    fun load(): Pair<EcuData?, EcuData?> {
        if (!file.exists()) return null to null
        val p = Properties()
        file.inputStream().use { p.load(it) }
        return get(p, "label", DataSource.ETIQUETA) to get(p, "diag", DataSource.FERRAMENTA_DIAGNOSTICO)
    }

    private fun put(p: Properties, k: String, d: EcuData?) {
        if (d == null) return
        p.setProperty("$k.part", d.partNumber)
        p.setProperty("$k.hw", d.hardware)
        p.setProperty("$k.sw", d.software)
        p.setProperty("$k.strategy", d.strategy)
        p.setProperty("$k.cal", d.calibration)
    }

    private fun get(p: Properties, k: String, src: DataSource): EcuData? {
        val part = p.getProperty("$k.part") ?: return null
        return EcuData(
            part, p.getProperty("$k.hw", ""), p.getProperty("$k.sw", ""),
            p.getProperty("$k.strategy", ""), p.getProperty("$k.cal", ""), src,
        )
    }
}
