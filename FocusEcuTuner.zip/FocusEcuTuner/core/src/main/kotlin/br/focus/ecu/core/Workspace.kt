package br.focus.ecu.core

import java.io.File
import java.time.Instant

/**
 * Área de trabalho: guarda o original (somente leitura), cópias de trabalho,
 * histórico de versões e log de auditoria. Todo arquivo tem SHA-256 registrado.
 */
class Workspace(root: File, private val clock: () -> Instant = { Instant.now() }) {
    enum class Kind { ORIGINAL, COPIA }

    data class Version(
        val id: String,
        val name: String,
        val kind: Kind,
        val sha256: String,
        val size: Int,
        val parentId: String?,
        val createdAt: String,
        val note: String,
    )

    private val filesDir = File(root, "files").also { it.mkdirs() }
    private val index = File(root, "index.tsv")
    private val auditFile = File(root, "audit.log")

    fun list(): List<Version> =
        if (!index.exists()) emptyList() else index.readLines().filter { it.isNotBlank() }.map(::parse)

    fun get(id: String): Version? = list().firstOrNull { it.id == id }

    fun fileOf(id: String): File = File(filesDir, "$id.bin")

    fun readBytes(id: String): ByteArray = fileOf(id).readBytes()

    fun importOriginal(name: String, bytes: ByteArray): Version =
        add(name, Kind.ORIGINAL, bytes, null, "Arquivo original importado")

    fun createWorkingCopy(parentId: String, note: String = "Cópia de trabalho"): Version {
        val src = get(parentId) ?: error("Versão $parentId não existe.")
        check(verify(parentId)) { "Integridade de $parentId falhou; cópia recusada." }
        return add("${src.name} (cópia)", Kind.COPIA, readBytes(parentId), parentId, note)
    }

    /**
     * EXPERIMENTAL: edição bruta de bytes, sempre gerando uma NOVA cópia.
     * Não interpreta mapas. Exige que exista um original salvo (backup).
     */
    fun editBytes(parentId: String, offset: Int, data: ByteArray, note: String): Version {
        require(data.isNotEmpty()) { "Nenhum byte para gravar." }
        check(list().any { it.kind == Kind.ORIGINAL }) { "Backup obrigatório: importe o original antes de editar." }
        val src = get(parentId) ?: error("Versão $parentId não existe.")
        check(verify(parentId)) { "Integridade de $parentId falhou; edição recusada." }
        val bytes = readBytes(parentId)
        require(offset >= 0 && offset + data.size <= bytes.size) { "Intervalo fora do arquivo." }
        data.copyInto(bytes, offset)
        return add("${src.name} (editado)", Kind.COPIA, bytes, parentId, "Edição bruta em 0x%X (%d bytes): %s".format(offset, data.size, note))
    }

    fun verify(id: String): Boolean {
        val v = get(id) ?: return false
        val f = fileOf(id)
        return f.exists() && FileTools.sha256(f.readBytes()) == v.sha256
    }

    fun audit(msg: String) {
        auditFile.appendText("${clock()} ${clean(msg)}\n")
    }

    fun auditLines(): List<String> = if (auditFile.exists()) auditFile.readLines() else emptyList()

    private fun add(name: String, kind: Kind, bytes: ByteArray, parent: String?, note: String): Version {
        val id = "v%03d".format(list().size + 1)
        val f = fileOf(id)
        f.writeBytes(bytes)
        f.setReadOnly()
        val v = Version(id, clean(name), kind, FileTools.sha256(bytes), bytes.size, parent, clock().toString(), clean(note))
        val linha = listOf(v.id, v.name, v.kind.name, v.sha256, v.size.toString(), v.parentId ?: "", v.createdAt, v.note)
        index.appendText(linha.joinToString("\t") + "\n")
        audit("${kind.name} ${v.id} criado: ${v.name} (${v.size} bytes, SHA-256 ${v.sha256.take(12)})")
        return v
    }

    private fun parse(line: String): Version {
        val p = line.split("\t", limit = 8)
        return Version(p[0], p[1], Kind.valueOf(p[2]), p[3], p[4].toInt(), p[5].ifEmpty { null }, p[6], p.getOrElse(7) { "" })
    }

    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ')
}
