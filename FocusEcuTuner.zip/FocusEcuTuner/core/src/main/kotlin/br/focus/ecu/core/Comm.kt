package br.focus.ecu.core

/**
 * Camada de comunicação. NENHUMA implementação real existe ainda: protocolo, hardware
 * e método de identificação precisam ser documentados e validados antes.
 */
interface EcuTransport {
    val name: String
    val isDemo: Boolean
    val supportsWrite: Boolean
    fun connect(): Result<Unit>
    fun disconnect()
    fun readIdentification(): Result<EcuData>
    fun supplyVoltage(): Double?
    fun writeCalibration(data: ByteArray): Result<Unit>
}

class UnavailableTransport : EcuTransport {
    override val name = "Nenhuma interface validada"
    override val isDemo = false
    override val supportsWrite = false
    private val msg = "Nenhuma interface de comunicação foi validada. Um adaptador OBD2 Bluetooth comum não é tratado como ferramenta de leitura ou gravação de mapas."
    override fun connect(): Result<Unit> = Result.failure(IllegalStateException(msg))
    override fun disconnect() = Unit
    override fun readIdentification(): Result<EcuData> = Result.failure(IllegalStateException(msg))
    override fun supplyVoltage(): Double? = null
    override fun writeCalibration(data: ByteArray): Result<Unit> = Result.failure(IllegalStateException(msg))
}

/** Transporte simulado só para testar a interface. Valores fictícios; nunca grava. */
class DemoTransport : EcuTransport {
    override val name = "Simulação (valores fictícios)"
    override val isDemo = true
    override val supportsWrite = false
    override fun connect(): Result<Unit> = Result.success(Unit)
    override fun disconnect() = Unit
    override fun readIdentification(): Result<EcuData> = Result.success(
        EcuData("DEMO-0000", "DEMO-HW", "DEMO-SW", "DEMO-EST", "DEMO-CAL", DataSource.FERRAMENTA_DIAGNOSTICO),
    )
    override fun supplyVoltage(): Double? = 12.6
    override fun writeCalibration(data: ByteArray): Result<Unit> =
        Result.failure(IllegalStateException("Gravação real é proibida no modo demonstração."))
}
