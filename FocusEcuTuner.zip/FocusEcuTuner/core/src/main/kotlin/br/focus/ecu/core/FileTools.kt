package br.focus.ecu.core

import java.security.MessageDigest
import java.util.zip.CRC32

data class FileInfo(
    val name: String,
    val size: Int,
    val sha256: String,
    val crc32: String,
    val fracFF: Double,
    val fracZero: Double,
    val notes: List<String>,
)

object FileTools {
    fun sha256(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    fun crc32(b: ByteArray): String {
        val c = CRC32()
        c.update(b)
        return "%08x".format(c.value)
    }

    /** Análise básica. NUNCA afirma compatibilidade: só tamanho, hashes e sinais óbvios de problema. */
    fun analyze(name: String, bytes: ByteArray): FileInfo {
        val notes = mutableListOf<String>()
        if (bytes.isEmpty()) {
            notes += "Arquivo vazio."
            return FileInfo(name, 0, sha256(bytes), crc32(bytes), 0.0, 0.0, notes)
        }
        var ff = 0
        var zero = 0
        for (b in bytes) {
            if (b == 0xFF.toByte()) ff++ else if (b == 0.toByte()) zero++
        }
        val fracFF = ff.toDouble() / bytes.size
        val fracZero = zero.toDouble() / bytes.size
        if (fracFF >= 0.99) notes += "Quase todo o arquivo é 0xFF: pode ser memória apagada ou leitura incorreta."
        if (fracZero >= 0.99) notes += "Quase todo o arquivo é 0x00: provável leitura incorreta."
        notes += "Tamanho: ${bytes.size} bytes (${bytes.size / 1024} KB)."
        notes += "Formato, estrutura e compatibilidade NÃO foram verificados: o aplicativo só confirma tamanho e hashes."
        return FileInfo(name, bytes.size, sha256(bytes), crc32(bytes), fracFF, fracZero, notes)
    }
}
