package br.focus.ecu.core

enum class FunctionStatus(val rotulo: String) {
    IMPLEMENTADA("Implementada"),
    EXPERIMENTAL("Experimental"),
    DEPENDE_HARDWARE("Depende de hardware/documentação"),
    NAO_IMPLEMENTADA("Não implementada"),
}

data class Feature(val nome: String, val status: FunctionStatus)

object Features {
    val all = listOf(
        Feature("Cadastro e avaliação de identidade da ECU", FunctionStatus.IMPLEMENTADA),
        Feature("Importação, hash e análise básica de arquivos", FunctionStatus.IMPLEMENTADA),
        Feature("Backup, cópias de trabalho e histórico de versões", FunctionStatus.IMPLEMENTADA),
        Feature("Comparação binária entre versões", FunctionStatus.IMPLEMENTADA),
        Feature("Relatório e log de auditoria", FunctionStatus.IMPLEMENTADA),
        Feature("Trava de gravação (sempre bloqueada hoje)", FunctionStatus.IMPLEMENTADA),
        Feature("Edição bruta de bytes em cópia (sem tela)", FunctionStatus.EXPERIMENTAL),
        Feature("Leitura de códigos de falha e parâmetros", FunctionStatus.DEPENDE_HARDWARE),
        Feature("Gravação na ECU", FunctionStatus.DEPENDE_HARDWARE),
        Feature("Editor de mapas e gráficos 2D/3D", FunctionStatus.NAO_IMPLEMENTADA),
        Feature("Módulo Desempenho e seção sobre pops and bangs", FunctionStatus.NAO_IMPLEMENTADA),
    )
}

object ReportBuilder {
    fun build(
        label: EcuData?,
        diag: EcuData?,
        compat: CompatResult,
        versions: List<Workspace.Version>,
        audit: List<String>,
        geradoEm: String,
    ): String = buildString {
        appendLine("RELATÓRIO FOCUS ECU TUNER — $geradoEm")
        appendLine("Veículo-alvo: Ford Focus 2012 2.0 Duratec Flex")
        appendLine()
        appendLine("== Identificação da ECU ==")
        appendLine("Situação: ${compat.status.rotulo}")
        compat.motivos.forEach { appendLine("- $it") }
        for ((titulo, d) in listOf("Etiqueta" to label, "Diagnóstico" to diag)) {
            appendLine("$titulo: " + (d?.let { "peça=${it.partNumber} hw=${it.hardware} sw=${it.software} estratégia=${it.strategy} cal=${it.calibration}" } ?: "não cadastrado"))
        }
        appendLine()
        appendLine("== Versões de arquivo ==")
        if (versions.isEmpty()) appendLine("Nenhum arquivo importado.")
        versions.forEach {
            appendLine("${it.id} | ${it.kind} | ${it.name} | ${it.size} bytes | pai=${it.parentId ?: "-"} | ${it.createdAt}")
            appendLine("   SHA-256 ${it.sha256}")
        }
        appendLine()
        appendLine("== Registro de operações ==")
        audit.forEach { appendLine(it) }
    }
}
