package br.focus.ecu.core

data class WriteContext(
    val compat: CompatStatus,
    val backupVerified: Boolean,
    val fileIntegrityOk: Boolean,
    val connected: Boolean,
    val protocolValidated: Boolean,
    val transportSupportsWrite: Boolean,
    val supplyVoltageOk: Boolean?, // null = desconhecida
    val demoMode: Boolean,
)

data class GateResult(val allowed: Boolean, val blockers: List<String>)

/** Trava de gravação: só libera se TODAS as condições forem satisfeitas. */
object WriteGate {
    fun evaluate(c: WriteContext): GateResult {
        val b = mutableListOf<String>()
        if (c.demoMode) b += "Modo demonstração ativo: gravação real é proibida."
        if (c.compat != CompatStatus.CONFIRMADA) b += "Identidade da ECU não confirmada (${c.compat.rotulo})."
        if (!c.backupVerified) b += "Backup do arquivo original ausente ou com integridade não verificada."
        if (!c.fileIntegrityOk) b += "Algum arquivo do histórico falhou na verificação de integridade."
        if (!c.connected) b += "Sem comunicação ativa com a ECU."
        if (!c.protocolValidated || !c.transportSupportsWrite) b += "Nenhum protocolo/hardware de gravação foi validado."
        when (c.supplyVoltageOk) {
            null -> b += "Tensão de alimentação desconhecida."
            false -> b += "Alimentação elétrica inadequada."
            true -> Unit
        }
        return GateResult(b.isEmpty(), b)
    }
}
