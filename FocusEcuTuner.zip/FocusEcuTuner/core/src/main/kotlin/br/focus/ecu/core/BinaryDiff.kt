package br.focus.ecu.core

data class DiffRange(val offset: Int, val length: Int)

data class DiffResult(
    val sizeA: Int,
    val sizeB: Int,
    val ranges: List<DiffRange>,
    val differingBytes: Int,
) {
    val sameSize: Boolean get() = sizeA == sizeB
    val identical: Boolean get() = sameSize && ranges.isEmpty()
}

object BinaryDiff {
    /** Compara byte a byte. Se os tamanhos diferem, a sobra conta como diferença. */
    fun compare(a: ByteArray, b: ByteArray): DiffResult {
        val common = minOf(a.size, b.size)
        val ranges = mutableListOf<DiffRange>()
        var start = -1
        for (i in 0 until common) {
            if (a[i] != b[i]) {
                if (start < 0) start = i
            } else if (start >= 0) {
                ranges += DiffRange(start, i - start)
                start = -1
            }
        }
        if (start >= 0) ranges += DiffRange(start, common - start)
        val tail = maxOf(a.size, b.size) - common
        if (tail > 0) {
            val last = ranges.lastOrNull()
            if (last != null && last.offset + last.length == common) {
                ranges[ranges.size - 1] = DiffRange(last.offset, last.length + tail)
            } else {
                ranges += DiffRange(common, tail)
            }
        }
        return DiffResult(a.size, b.size, ranges, ranges.sumOf { it.length })
    }
}
