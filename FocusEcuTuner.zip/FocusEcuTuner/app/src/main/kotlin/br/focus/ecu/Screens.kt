@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package br.focus.ecu

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.focus.ecu.core.*

@Composable
fun FocusApp(vm: AppViewModel) {
    var aba by remember { mutableIntStateOf(0) }
    val abas = listOf(
        "Painel" to Icons.Filled.Home,
        "ECU" to Icons.Filled.Settings,
        "Arquivos" to Icons.Filled.Info,
        "Comparar" to Icons.Filled.Search,
        "Relatório" to Icons.Filled.Check,
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                abas.forEachIndexed { i, (nome, icone) ->
                    NavigationBarItem(
                        selected = aba == i,
                        onClick = { aba = i },
                        icon = { Icon(icone, contentDescription = nome) },
                        label = { Text(nome, maxLines = 1) },
                    )
                }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            vm.message?.let {
                Card(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(Modifier.padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(it, Modifier.weight(1f))
                        TextButton(onClick = { vm.message = null }) { Text("OK") }
                    }
                }
            }
            when (aba) {
                0 -> PainelTela(vm)
                1 -> EcuTela(vm)
                2 -> ArquivosTela(vm)
                3 -> CompararTela(vm)
                else -> RelatorioTela(vm)
            }
        }
    }
}

@Composable
fun Tela(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    content = content,
)

@Composable
fun Bloco(titulo: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
fun Campo(rotulo: String, valor: String, mudou: (String) -> Unit) = OutlinedTextField(
    value = valor, onValueChange = mudou, label = { Text(rotulo) },
    singleLine = true, modifier = Modifier.fillMaxWidth(),
)

@Composable
fun PainelTela(vm: AppViewModel) = Tela {
    val sistemaEscuro = isSystemInDarkTheme()
    Bloco("Veículo-alvo") {
        Text("Ford Focus 2012 • 2.0 Duratec Flex (aspirado)")
        Text("Referência inicial (NÃO confirmada): ${EcuIdentifier.REFERENCIA_INICIAL}")
    }
    Bloco("Identificação da ECU") {
        Text(vm.compat.status.rotulo, fontWeight = FontWeight.Bold)
        vm.compat.motivos.forEach { Text("• $it") }
    }
    Bloco("Conexão") {
        Text(vm.connectionName)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Modo demonstração", Modifier.weight(1f))
            Switch(checked = vm.demo, onCheckedChange = { vm.alternarDemo(it) })
        }
        if (vm.demo) OutlinedButton(onClick = { vm.lerDemo() }) { Text("Ler identificação (simulada)") }
    }
    Bloco(if (vm.gate.allowed) "Gravação: liberada pela trava" else "Gravação: BLOQUEADA") {
        vm.gate.blockers.forEach { Text("• $it") }
    }
    Bloco("Aparência") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Tema escuro", Modifier.weight(1f))
            Switch(checked = vm.darkTheme ?: sistemaEscuro, onCheckedChange = { vm.darkTheme = it })
        }
    }
    Bloco("Estado das funções") {
        Features.all.forEach { Text("• ${it.status.rotulo}: ${it.nome}") }
    }
}

@Composable
fun FormEcu(titulo: String, fonte: DataSource, atual: EcuData?, onSalvar: (EcuData) -> Unit) {
    var peca by remember(atual) { mutableStateOf(atual?.partNumber ?: "") }
    var hw by remember(atual) { mutableStateOf(atual?.hardware ?: "") }
    var sw by remember(atual) { mutableStateOf(atual?.software ?: "") }
    var est by remember(atual) { mutableStateOf(atual?.strategy ?: "") }
    var cal by remember(atual) { mutableStateOf(atual?.calibration ?: "") }
    Bloco(titulo) {
        Campo("Número da peça (ex.: AU75-12A650-CB)", peca) { peca = it }
        Campo("Hardware", hw) { hw = it }
        Campo("Versão de software", sw) { sw = it }
        Campo("Estratégia", est) { est = it }
        Campo("Calibração", cal) { cal = it }
        Button(onClick = { onSalvar(EcuData(peca.trim(), hw.trim(), sw.trim(), est.trim(), cal.trim(), fonte)) }) { Text("Salvar") }
    }
}

@Composable
fun EcuTela(vm: AppViewModel) = Tela {
    Text("Cadastre os dados das DUAS fontes. Não presuma que todo Focus 2012 usa a mesma ECU.")
    FormEcu("Dados da etiqueta física", DataSource.ETIQUETA, vm.label) { vm.salvarEcu(it) }
    FormEcu("Dados lidos por ferramenta de diagnóstico", DataSource.FERRAMENTA_DIAGNOSTICO, vm.diag) { vm.salvarEcu(it) }
}

@Composable
fun ArquivosTela(vm: AppViewModel) = Tela {
    val cr = LocalContext.current.contentResolver
    val seletor = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importar(cr, uri)
    }
    Button(onClick = { seletor.launch(arrayOf("*/*")) }) { Text("Importar arquivo original") }
    vm.lastInfo?.let { i ->
        Bloco("Última análise: ${i.name}") {
            Text("SHA-256: ${i.sha256}", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            Text("CRC32: ${i.crc32}", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            i.notes.forEach { Text("• $it") }
        }
    }
    if (vm.versions.isEmpty()) Text("Nenhum arquivo importado ainda.")
    vm.versions.forEach { v ->
        Bloco("${v.id} • " + if (v.kind == Workspace.Kind.ORIGINAL) "Original (protegido)" else "Cópia de trabalho") {
            Text(v.name)
            Text("${v.size} bytes • ${v.createdAt}", fontSize = 12.sp)
            Text("SHA-256: ${v.sha256}", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.criarCopia(v.id) }) { Text("Criar cópia") }
                OutlinedButton(onClick = { vm.verificar(v.id) }) { Text("Verificar") }
            }
        }
    }
}

@Composable
fun CompararTela(vm: AppViewModel) = Tela {
    var a by remember { mutableStateOf<String?>(null) }
    var b by remember { mutableStateOf<String?>(null) }
    if (vm.versions.size < 2) Text("Importe um original e crie uma cópia (ou importe dois arquivos) para comparar.")
    Text("Arquivo A")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        vm.versions.forEach { v -> FilterChip(selected = a == v.id, onClick = { a = v.id }, label = { Text(v.id) }) }
    }
    Text("Arquivo B")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        vm.versions.forEach { v -> FilterChip(selected = b == v.id, onClick = { b = v.id }, label = { Text(v.id) }) }
    }
    Button(enabled = a != null && b != null, onClick = { vm.comparar(a!!, b!!) }) { Text("Comparar") }
    vm.diff?.let { d ->
        Bloco(if (d.identical) "Arquivos idênticos" else "${d.differingBytes} bytes diferentes") {
            Text("Tamanhos: ${d.sizeA} x ${d.sizeB} bytes" + if (d.sameSize) "" else " (diferentes)")
            d.ranges.take(100).forEach {
                Text("0x%X  (%d bytes)".format(it.offset, it.length), fontFamily = FontFamily.Monospace)
            }
            if (d.ranges.size > 100) Text("… e mais ${d.ranges.size - 100} faixas (veja o relatório).")
        }
    }
}

@Composable
fun RelatorioTela(vm: AppViewModel) = Tela {
    val cr = LocalContext.current.contentResolver
    val exportador = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) vm.exportar(cr, uri)
    }
    val texto = vm.relatorio()
    Button(onClick = { exportador.launch("relatorio_ecu.txt") }) { Text("Exportar relatório (.txt)") }
    Text(texto, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
}
