package br.focus.ecu

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import br.focus.ecu.core.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.time.Instant

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val root = File(app.filesDir, "workspace").also { it.mkdirs() }
    private val ws = Workspace(root)
    private val store = EcuStore(File(root, "ecu.properties"))
    private val transport: EcuTransport = UnavailableTransport()
    private val demoTransport = DemoTransport()

    var label by mutableStateOf<EcuData?>(null); private set
    var diag by mutableStateOf<EcuData?>(null); private set
    var versions by mutableStateOf<List<Workspace.Version>>(emptyList()); private set
    var audit by mutableStateOf<List<String>>(emptyList()); private set
    var gate by mutableStateOf(GateResult(false, emptyList())); private set
    var lastInfo by mutableStateOf<FileInfo?>(null); private set
    var diff by mutableStateOf<DiffResult?>(null); private set
    var demo by mutableStateOf(false); private set
    var darkTheme by mutableStateOf<Boolean?>(null)
    var message by mutableStateOf<String?>(null)

    val connectionName: String get() = if (demo) demoTransport.name else transport.name
    val compat: CompatResult get() = EcuIdentifier.evaluate(label, diag)

    init {
        val (l, d) = store.load()
        label = l
        diag = d
        refresh()
    }

    private fun refresh() {
        versions = ws.list()
        audit = ws.auditLines().takeLast(200)
        val originais = versions.filter { it.kind == Workspace.Kind.ORIGINAL }
        gate = WriteGate.evaluate(
            WriteContext(
                compat = compat.status,
                backupVerified = originais.isNotEmpty() && originais.all { ws.verify(it.id) },
                fileIntegrityOk = versions.all { ws.verify(it.id) },
                connected = false,
                protocolValidated = false,
                transportSupportsWrite = transport.supportsWrite,
                supplyVoltageOk = null,
                demoMode = demo,
            ),
        )
    }

    fun salvarEcu(d: EcuData) {
        if (d.source == DataSource.ETIQUETA) label = d else diag = d
        store.save(label, diag)
        ws.audit("Cadastro da ECU (${d.source}) atualizado: peça ${d.partNumber}")
        message = "Cadastro salvo."
        refresh()
    }

    fun alternarDemo(ligado: Boolean) {
        demo = ligado
        ws.audit(if (ligado) "Modo demonstração ligado" else "Modo demonstração desligado")
        refresh()
    }

    fun lerDemo() {
        val d = demoTransport.readIdentification().getOrNull() ?: return
        message = "SIMULADO (não salvo no cadastro): peça ${d.partNumber}, tensão ${demoTransport.supplyVoltage()} V."
    }

    fun importar(cr: ContentResolver, uri: Uri) {
        try {
            val nome = cr.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            } ?: "arquivo.bin"
            val bytes = cr.openInputStream(uri)?.use { lerLimitado(it, MAX_BYTES) }
            when {
                bytes == null -> message = "Arquivo grande demais (limite de 16 MB) ou ilegível."
                bytes.isEmpty() -> message = "O arquivo está vazio."
                else -> {
                    lastInfo = FileTools.analyze(nome, bytes)
                    val v = ws.importOriginal(nome, bytes)
                    message = "Original importado como ${v.id}. Ele fica protegido; edite apenas cópias."
                }
            }
        } catch (e: Exception) {
            message = "Falha ao importar: ${e.message}"
        }
        refresh()
    }

    fun criarCopia(id: String) {
        message = try {
            "Cópia criada: ${ws.createWorkingCopy(id).id}."
        } catch (e: Exception) {
            "Não foi possível criar a cópia: ${e.message}"
        }
        refresh()
    }

    fun verificar(id: String) {
        val ok = ws.verify(id)
        ws.audit("Verificação de integridade de $id: ${if (ok) "OK" else "FALHOU"}")
        message = if (ok) "Integridade de $id confirmada (SHA-256 confere)." else "ALERTA: $id foi alterado ou está ausente."
        refresh()
    }

    fun comparar(a: String, b: String) {
        diff = BinaryDiff.compare(ws.readBytes(a), ws.readBytes(b))
        ws.audit("Comparação $a x $b: ${diff?.differingBytes} bytes diferentes")
        refresh()
    }

    fun relatorio(): String = ReportBuilder.build(label, diag, compat, versions, audit, Instant.now().toString())

    fun exportar(cr: ContentResolver, uri: Uri) {
        message = try {
            cr.openOutputStream(uri)?.use { it.write(relatorio().toByteArray()) }
            ws.audit("Relatório exportado")
            "Relatório exportado."
        } catch (e: Exception) {
            "Falha ao exportar: ${e.message}"
        }
        refresh()
    }

    private fun lerLimitado(ins: InputStream, max: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            total += n
            if (total > max) return null
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    companion object {
        const val MAX_BYTES = 16 * 1024 * 1024
    }
}
